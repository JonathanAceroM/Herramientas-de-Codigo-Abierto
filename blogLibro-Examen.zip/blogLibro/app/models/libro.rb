class Libro < ActiveRecord::Base
		validates :titulo, presence: true, uniqueness: true 
		validates :autor, presence: true, length: { minimum: 5 }
end
